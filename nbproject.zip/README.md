#PVI App#

##Getting started##
1. Clone the project to wherever you'd like
2. Run `composer install`
3. run "dev-server.bat"
4. Open your webbrowser and go to `localhost:8000`
