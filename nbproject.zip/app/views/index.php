<div class="container">
    <div class="well">
        <p>
            <a href="<?= url('/pvi') ?>">PVI</a>
            |
            <a href="<?= url('/analysis') ?>">Analysis</a>
        </p>
    </div>
</div>